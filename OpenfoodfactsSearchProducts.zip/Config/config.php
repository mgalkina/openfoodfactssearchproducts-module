<?php

return [
    'name' => 'OpenfoodfactsSearchProducts'
];
